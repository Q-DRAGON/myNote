import React, {Component} from 'react'
import './App.css'
import DemoButton from './demo/DemoButton'
import DemoInput from './demo/DemoInput'

class App extends Component {
    render() {
        // 参考 https://ant.design/components/input-cn
        // 已经实现了基本的 Input, 现在要添加一个功能
        // Input 右边有一个「x」, 要求点击后可以清空输入框的内容

        return (
            <div className="App">
                <DemoButton/>
                <DemoInput/>
            </div>
        )
    }
}

export default App
