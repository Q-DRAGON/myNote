import React, {Component} from 'react'
import './Input.css'

class Button extends Component {
    onClear = () => {
        // 在这里实现 onClear 代码, 可以添加必要的其他代码
    }
    render() {
        return (
            <span className="input-wrapper">
                <input className="gua-input" />
                <span className="clear-button" onClick={this.onClear}>&#215;</span>
            </span>
        )
    }
}

export default Button
