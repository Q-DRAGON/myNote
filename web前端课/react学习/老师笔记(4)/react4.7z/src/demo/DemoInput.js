import React, {Component} from 'react'
import Input from '../components/Input'

class DemoInput extends Component {
    render() {
        return (
            <div>
                <h1>Input 输入框</h1>
                <Input/>
            </div>
        )
    }
}

export default DemoInput
